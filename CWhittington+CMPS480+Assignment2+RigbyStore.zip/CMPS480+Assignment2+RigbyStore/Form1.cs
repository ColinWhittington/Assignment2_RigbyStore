﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMPS480_Assignment2_RigbyStore
{
    public partial class Form1 : Form
    {
        List<Panel> listPanel = new List<Panel>();   //CWhittington 03-23-21, NEW 1L define List
        protected int TextBoxCount { get; set; }   //CWhittington 03-23-21, NEW 1L get and set text box count

        //CWhittington 03-23-21, NEW 2L private variables to read and write files 
        private StreamWriter fileWriter;
        private StreamReader fileReader;

        public enum TextBoxIndices { ID, Name, Total, Paid, Rate, Personality }   //CWhittington 03-23-21, NEW 1L enum indices

        //CWhittington 03-23-21, NEW 3L initalize form
        public Form1()
        {
            InitializeComponent();
        }

        //CWhittington 03-23-21, NEW 22L get and set each variable from the text boxes and store them to be accessed later
        public class Record
        {
            public int ID { get; set; }
            public string Name { get; set; }
            public int Total { get; set; }
            public string Paid { get; set; }
            public int Rate { get; set; }
            public string Personality { get; set; }

            public Record() : this(0, string.Empty, 0, string.Empty, 0, string.Empty) { }

            public Record(int productID, string productName, int productTotal, string productPaid, int productRate, string productPersonality)
            {
                ID = productID;
                Name = productName;
                Total = productTotal;
                Paid = productPaid;
                Rate = productRate;
                Personality = productPersonality;
            }
        }

        //CWhittington 03-23-21, NEW 9L method to clear text boxes
        public void ClearTextBoxes()
        {
            idTextBox.Clear();
            nameTextBox.Clear();
            totalTextBox.Clear();
            paidTextBox.Clear();
            rateTextBox.Clear();
            personalityTextBox.Clear();
        }

        //CWhittington 03-23-21, NEW 8L method to set the variables into values through text boxes
        public void SetTextBoxValues(string[] values)
        {
            idTextBox.Text = values[(int)TextBoxIndices.ID];
            nameTextBox.Text = values[(int)TextBoxIndices.Name];
            totalTextBox.Text = values[(int)TextBoxIndices.Total];
            paidTextBox.Text = values[(int)TextBoxIndices.Paid];
            rateTextBox.Text = values[(int)TextBoxIndices.Rate];
            personalityTextBox.Text = values[(int)TextBoxIndices.Rate];
        }

        //CWhittington 03-23-21, NEW create string array method to access info later
        public string[] GetTextBoxValues()
        {
            return new string[]
            {
                idTextBox.Text,
                nameTextBox.Text,
                totalTextBox.Text,
                paidTextBox.Text,
                rateTextBox.Text,
                personalityTextBox.Text
            };
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            listPanel[1].BringToFront();   //CWhittington 03-23-21, NEW brings to add page
        }

        //CWhittington 03-23-21, NEW 8L when the form loads to adds the panels into the list, and brings forth panel1 as main
        private void Form1_Load(object sender, EventArgs e)
        {
            listPanel.Add(panel1);
            listPanel.Add(panel2);
            listPanel.Add(panel3);
            listPanel.Add(panel4);
            listPanel[0].BringToFront();
        }

        private void nextButton_Click(object sender, EventArgs e)
        {
            //CWhittington 03-23-21, NEW accidental double click   
        }

        private void prevButton_Click(object sender, EventArgs e)
        {
            //CWhittington 03-23-21, NEW accidental double click
        }

        private void mainMenuButton_Click(object sender, EventArgs e)
        {
            listPanel[0].BringToFront();   //CWhittington 03-23-21, NEW goes to main when they click main
        }

        //CWhittington 03-23-21, NEW 18L save function
        private void saveButton_Click(object sender, EventArgs e)
        {
            string[] values = GetTextBoxValues();   //CWhittington 03-23-21, NEW call back string array

            //CWhittington 03-23-21, NEW 3L creates variable record and stores the message into the text file
            string record = "Order number #" + idTextBox.Text + " consisted of " + nameTextBox.Text + ". It cost $" + totalTextBox.Text + 
                " and was paid via " + paidTextBox.Text + ". The customer rated the product a " + rateTextBox.Text + " and their personality was " 
                + personalityTextBox.Text + "\n";

            //CWhittington 03-23-21, NEW 2L save dialog to access files and get new file
            SaveFileDialog saver = new SaveFileDialog();
            saver.ShowDialog();

            //CWhittington 03-23-21, NEW if the file is selected then it saves the above message onto it, and gives a good job message
            if (saver.FileName != "")
            {
                File.AppendAllText(saver.FileName, record);
                ClearTextBoxes();
                MessageBox.Show("The entry was sucessfulled added!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        //CWhittington 03-23-21, NEW NOTE I COULD NOT GET THE MODIY TEXT TO WORK
        private void modifyButton_Click(object sender, EventArgs e)
        {
            listPanel[2].BringToFront();

            DialogResult result;
            string fileName;

            using (OpenFileDialog fileChooser = new OpenFileDialog())
            {
                result = fileChooser.ShowDialog();
                fileName = fileChooser.FileName;
            }

            FileStream input = new FileStream(fileName, FileMode.Open, FileAccess.Read);

            fileReader = new StreamReader(input);
        }

        private void mainButton2_Click(object sender, EventArgs e)
        {
            listPanel[0].BringToFront();   //CWhittington 03-23-21, NEW back to home page
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //CWhittington 03-23-21, NEW accidetnal double click
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //CWhittington 03-23-21, NEW accidental double click
        }

        private void button5_Click(object sender, EventArgs e)
        {
            listPanel[0].BringToFront();   //CWhittington 03-23-21, NEW go to main menu
        }

        private void reportingButton_Click(object sender, EventArgs e)
        {
            listPanel[3].BringToFront();   //CWhittington 03-23-21, NEW go to reporting page
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            //CWhittington 03-23-21, NEW 2L when button is clicked, gives a file to choose
            Stream myStream;
            OpenFileDialog fileChooser = new OpenFileDialog();

            //CWhittington 03-23-21, NEW 8L if conditions are met, will display text into richtextbox
            if (fileChooser.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if ((myStream = fileChooser.OpenFile()) != null)
                {
                    string outputAll = fileChooser.FileName;
                    string fileText = File.ReadAllText(outputAll);
                    richTextBox1.Text = fileText;
                }
            }
        }
    }
}
